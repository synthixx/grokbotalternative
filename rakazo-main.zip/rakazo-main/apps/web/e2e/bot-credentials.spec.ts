import type { Page } from "@playwright/test";
import { expect, test } from "@playwright/test";
import { captureScreenshot, completeOnboarding, createNamedBot, rpc, signup } from "./helpers";

// Fake values only: this spec proves the UI and API never echo a saved credential.
const SENTINEL = "fake-bot-credential-values-never-leak";
const REPLACEMENT = "fake-bot-credential-value-two";
const CREDENTIAL_NAME = "example_api";

test("bot credentials list, add, replace and remove without leaking values", async ({
  page,
}, testInfo) => {
  const stamp = Date.now();
  await signup(page, `bot-credentials-${stamp}@rakazo.test`, "password12", "Bot Credentials");
  await completeOnboarding(page);
  const botName = `Credentials ${stamp}`;
  const botId = await createNamedBot(page, botName);

  await page.locator("main").getByRole("button", { name: botName, exact: true }).click();
  const settings = page.getByTestId("bot-settings");
  await expect(settings).toBeVisible();
  // The Advanced <details> mounts the Credentials section on first open, not on render.
  await settings.getByTestId("bot-settings-advanced").evaluate((element) => {
    (element as HTMLDetailsElement).open = true;
  });
  const credentials = settings.getByTestId("bot-credentials");
  await expect(credentials).toBeVisible();
  await expect(credentials.getByTestId("bot-credentials-empty")).toBeVisible();

  // Add: a password field holds the value, which is cleared once the save starts.
  await credentials.getByTestId("credential-add").click();
  const addForm = credentials.getByTestId("credential-add-form");
  await addForm.getByTestId("credential-name").fill(CREDENTIAL_NAME);
  await addForm.getByTestId("credential-origin").fill("https://api.example.test");
  const valueInput = addForm.getByTestId("credential-value");
  await expect(valueInput).toHaveAttribute("type", "password");
  await expect(valueInput).toHaveAttribute("autocomplete", "new-password");
  await valueInput.fill(SENTINEL);
  await captureScreenshot(page, testInfo, "bot-credentials-add");
  await addForm.getByTestId("credential-add-save").click();

  const row = credentials.getByTestId("bot-credential-row");
  await expect(row).toHaveCount(1);
  await expect(row).toContainText(CREDENTIAL_NAME);
  await expect(row).toContainText("https://api.example.test");
  await expect(row).toContainText("Bearer token");
  await expect(addForm).toHaveCount(0);

  // The API returns metadata only, and no input still holds the value.
  const listed = await rpc<Array<Record<string, unknown>>>(page, "botSecrets/list", { botId });
  expect(listed).toHaveLength(1);
  expect(listed[0]).toMatchObject({
    name: CREDENTIAL_NAME,
    origin: "https://api.example.test",
    auth: { type: "bearer" },
  });
  expect(JSON.stringify(listed)).not.toContain(SENTINEL);
  expect(JSON.stringify(listed)).not.toContain("ciphertext");
  await expectNoLeakedInputValue(page, SENTINEL);

  // Replace: keeps the destination, writes a new value, leaves the old one gone.
  const replaced = page.waitForResponse(
    (response) => response.url().includes("/rpc/botSecrets/put") && response.ok(),
  );
  await credentials.getByTestId(`credential-replace-${CREDENTIAL_NAME}`).click();
  await credentials.getByTestId("credential-replace-value").fill(REPLACEMENT);
  await credentials.getByTestId("credential-replace-save").click();
  await replaced;
  await expect(row).toHaveCount(1);
  await expect(credentials.getByTestId("credential-replace-value")).toHaveCount(0);
  await expectNoLeakedInputValue(page, SENTINEL);
  await expectNoLeakedInputValue(page, REPLACEMENT);
  await captureScreenshot(page, testInfo, "bot-credentials-replace");

  // Remove: needs an explicit confirm, then the empty state returns.
  await credentials.getByTestId(`credential-remove-${CREDENTIAL_NAME}`).click();
  await expect(credentials).toContainText(`Remove ${CREDENTIAL_NAME}?`);
  const removed = page.waitForResponse(
    (response) => response.url().includes("/rpc/botSecrets/remove") && response.ok(),
  );
  await credentials.getByTestId(`credential-remove-confirm-${CREDENTIAL_NAME}`).click();
  await removed;
  await expect(row).toHaveCount(0);
  await expect(credentials.getByTestId("bot-credentials-empty")).toBeVisible();
  expect(await rpc<unknown[]>(page, "botSecrets/list", { botId })).toHaveLength(0);
  await captureScreenshot(page, testInfo, "bot-credentials-removed");
});

/** Fail if any live input value still carries a protected value. */
async function expectNoLeakedInputValue(page: Page, value: string) {
  const leaked = await page.evaluate((needle) => {
    const inputs = Array.from(document.querySelectorAll("input, textarea"));
    return inputs.some((input) => {
      const field = input as HTMLInputElement | HTMLTextAreaElement;
      return field.value.includes(needle);
    });
  }, value);
  expect(leaked).toBe(false);
}
