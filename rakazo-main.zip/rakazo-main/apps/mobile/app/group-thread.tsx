export { default } from "./thread";
